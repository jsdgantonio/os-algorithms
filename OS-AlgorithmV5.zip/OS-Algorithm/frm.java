class frm {

    public static void main(String[] args){
      MyFrame f = new MyFrame();
      f.setVisible(true);
    }
  }