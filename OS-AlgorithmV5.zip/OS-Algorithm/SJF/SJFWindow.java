package SJF;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class SJFWindow extends JFrame {
    private final SJF sjf;
    private final DefaultListModel<String> processListModel;

    public SJFWindow(JFrame parentFrame) {
        setTitle("SJF Scheduling");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        sjf = new SJF();
        processListModel = new DefaultListModel<>();

        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Add Process"));

        JPanel processListPanel = new JPanel(new BorderLayout());
        processListPanel.setBorder(BorderFactory.createTitledBorder("Processes"));

        JPanel resultPanel = new JPanel(new BorderLayout());
        resultPanel.setBorder(BorderFactory.createTitledBorder("Results"));

        JTextField processIdField = new JTextField();
        JTextField arrivalTimeField = new JTextField();
        JTextField burstTimeField = new JTextField();
        JTable resultTable = new JTable();

        JList<String> processList = new JList<>(processListModel);

        inputPanel.add(new JLabel("Process ID:"));
        inputPanel.add(processIdField);

        inputPanel.add(new JLabel("Arrival Time:"));
        inputPanel.add(arrivalTimeField);

        inputPanel.add(new JLabel("Burst Time:"));
        inputPanel.add(burstTimeField);

        JButton addProcessButton = new JButton("Add Process");
        JButton clearProcessesButton = new JButton("Clear");
        JButton scheduleButton = new JButton("Schedule");
        JButton backButton = new JButton("Back");

        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonsPanel.add(addProcessButton);
        buttonsPanel.add(clearProcessesButton);
        buttonsPanel.add(scheduleButton);
        buttonsPanel.add(backButton);

        processListPanel.add(new JScrollPane(processList), BorderLayout.CENTER);

        resultPanel.add(new JScrollPane(resultTable), BorderLayout.CENTER);

        // Add action listeners
        addProcessButton.addActionListener(e -> {
            String id = processIdField.getText().trim();
            String arrivalTimeStr = arrivalTimeField.getText().trim();
            String burstTimeStr = burstTimeField.getText().trim();

            if (id.isEmpty() || arrivalTimeStr.isEmpty() || burstTimeStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                int arrivalTime = Integer.parseInt(arrivalTimeStr);
                int burstTime = Integer.parseInt(burstTimeStr);

                sjf.addProcess(id, arrivalTime, burstTime);
                processListModel.addElement("P" + id + " [AT: " + arrivalTime + ", BT: " + burstTime + "]");

                processIdField.setText("");
                arrivalTimeField.setText("");
                burstTimeField.setText("");

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Arrival Time and Burst Time must be integers.", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        clearProcessesButton.addActionListener(e -> {
            sjf.clearProcesses(); // Clears the processes from SJF
            processListModel.clear(); // Clears the process list model
            resultTable.setModel(new javax.swing.table.DefaultTableModel()); // Clears the result table model
        
        });

        scheduleButton.addActionListener(e -> sjf.schedule(this, resultTable));

        backButton.addActionListener(e -> {
            this.dispose(); // Close the current window
            parentFrame.setVisible(true); // Return to the main frame
        });

        // Layout the window
        setLayout(new BorderLayout(10, 10));
        add(inputPanel, BorderLayout.NORTH);
        add(processListPanel, BorderLayout.WEST);
        add(resultPanel, BorderLayout.CENTER);
        add(buttonsPanel, BorderLayout.SOUTH);

        setVisible(true);
    }
}
