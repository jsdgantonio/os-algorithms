package CLook;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class CLOOKWindow extends JFrame {

    public CLOOKWindow(JFrame parentFrame) {
        setTitle("C-LOOK Disk Scheduling");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setUIFont(new Font("Roboto", Font.PLAIN, 14));

        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Input Parameters"));

        JPanel resultPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        resultPanel.setBorder(BorderFactory.createTitledBorder("Results"));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));

        JTextField currentPositionField = new JTextField();
        JTextField trackSizeField = new JTextField();
        JTextField seekRateField = new JTextField();
        JTextField requestsField = new JTextField();

        inputPanel.add(new JLabel("Current Position:"));
        inputPanel.add(currentPositionField);

        inputPanel.add(new JLabel("Track Size:"));
        inputPanel.add(trackSizeField);

        inputPanel.add(new JLabel("Seek Rate:"));
        inputPanel.add(seekRateField);

        inputPanel.add(new JLabel("Requests (comma-separated):"));
        inputPanel.add(requestsField);

        JLabel totalHeadMovementLabel = new JLabel("Total Head Movement: ");
        JLabel seekTimeLabel = new JLabel("Seek Time: ");
        JLabel sequenceLabel = new JLabel("Seek Sequence: ");

        resultPanel.add(totalHeadMovementLabel);
        resultPanel.add(seekTimeLabel);
        resultPanel.add(sequenceLabel);

        JButton computeButton = new JButton("Compute");
        JButton backButton = new JButton("Back");
        JButton clearButton = new JButton("Clear");  // Clear button

        buttonPanel.add(computeButton);  // First button - Compute
        buttonPanel.add(clearButton);    // Second button - Clear (between Compute and Back)
        buttonPanel.add(backButton);     // Third button - Back

        // Compute button action listener
        computeButton.addActionListener(e -> {
            try {
                int currentPosition = Integer.parseInt(currentPositionField.getText().trim());
                int trackSize = Integer.parseInt(trackSizeField.getText().trim());
                int seekRate = Integer.parseInt(seekRateField.getText().trim());

                String[] requestStrings = requestsField.getText().trim().split(",");
                int[] requests = Arrays.stream(requestStrings).mapToInt(Integer::parseInt).toArray();

                // scheduling
                CLOOK cLook = new CLOOK();
                StringBuilder seekSequenceBuilder = new StringBuilder();
                int totalHeadMovement = cLook.schedule(currentPosition, trackSize, requests, seekRate, seekSequenceBuilder);

                // results
                totalHeadMovementLabel.setText("Total Head Movement: " + totalHeadMovement);
                seekTimeLabel.setText("Seek Time: " + (totalHeadMovement * seekRate));
                sequenceLabel.setText("Seek Sequence: " + seekSequenceBuilder.toString());

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid input! Please check your fields.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Back button action listener
        backButton.addActionListener(e -> {
            this.dispose();
            parentFrame.setVisible(true);
        });

        // Clear button action listener
        clearButton.addActionListener(e -> {
            // Clear all input fields
            currentPositionField.setText("");
            trackSizeField.setText("");
            seekRateField.setText("");
            requestsField.setText("");

            // Clear result labels
            totalHeadMovementLabel.setText("Total Head Movement: ");
            seekTimeLabel.setText("Seek Time: ");
            sequenceLabel.setText("Seek Sequence: ");
        });

        setLayout(new BorderLayout(10, 10));
        add(inputPanel, BorderLayout.NORTH);
        add(resultPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private static void setUIFont(Font font) {
        java.util.Enumeration<Object> keys = UIManager.getDefaults().keys();
        while (keys.hasMoreElements()) {
            Object key = keys.nextElement();
            Object value = UIManager.get(key);
            if (value instanceof javax.swing.plaf.FontUIResource) {
                UIManager.put(key, font);
            }
        }
    }
}
