package CLook;

import java.util.*;

public class CLOOK {

    public int schedule(int currentPosition, int trackSize, int[] requests, int seekRate, StringBuilder seekSequence) {
        int totalHeadMovement = 0;

        // Sort the requests array
        Arrays.sort(requests);

        // Separate the requests into two categories
        List<Integer> left = new ArrayList<>();
        List<Integer> right = new ArrayList<>();

        for (int request : requests) {
            if (request < currentPosition) {
                left.add(request);
            } else {
                right.add(request);
            }
        }

        // Process requests to the right first
        seekSequence.append(currentPosition);
        totalHeadMovement += moveDiskArm(currentPosition, right, seekSequence);

        // Jump back and process requests to the left
        if (!left.isEmpty()) {
            totalHeadMovement += moveDiskArm(right.get(right.size() - 1), left, seekSequence);
        }

        return totalHeadMovement;
    }

    private int moveDiskArm(int start, List<Integer> requests, StringBuilder seekSequence) {
        int headMovement = 0;

        for (int request : requests) {
            headMovement += Math.abs(start - request);
            start = request;
            seekSequence.append(" -> ").append(request);
        }

        return headMovement;
    }
}
