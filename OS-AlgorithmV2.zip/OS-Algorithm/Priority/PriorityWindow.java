import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;

public class PriorityWindow extends JFrame {
    private JTextField idField, priorityField, arrivalField, burstField;
    private JTextArea outputArea;
    private List<Priority.Process> processes;

    public PriorityWindow() {
        setTitle("Priority Preemptive Scheduling");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        processes = new ArrayList<>();

        // Input fields for the process details
        JPanel inputPanel = new JPanel(new GridLayout(5, 2));
        inputPanel.add(new JLabel("Process ID:"));
        idField = new JTextField();
        inputPanel.add(idField);

        inputPanel.add(new JLabel("Priority:"));
        priorityField = new JTextField();
        inputPanel.add(priorityField);

        inputPanel.add(new JLabel("Arrival Time:"));
        arrivalField = new JTextField();
        inputPanel.add(arrivalField);

        inputPanel.add(new JLabel("Burst Time:"));
        burstField = new JTextField();
        inputPanel.add(burstField);

        // Add Process Button
        JButton addButton = new JButton("Add Process");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addProcess();
            }
        });
        inputPanel.add(addButton);

        // Output area to display scheduling results
        outputArea = new JTextArea();
        outputArea.setEditable(false);

        // Schedule Button
        JButton scheduleButton = new JButton("Schedule");
        scheduleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                scheduleProcesses();
            }
        });

        // Add components to the JFrame
        add(inputPanel, BorderLayout.NORTH);
        add(new JScrollPane(outputArea), BorderLayout.CENTER);
        add(scheduleButton, BorderLayout.SOUTH);

        setVisible(true);
    }

    // Add process details from the input fields to the processes list
    private void addProcess() {
        try {
            String id = idField.getText();
            int priority = Integer.parseInt(priorityField.getText());
            int arrival = Integer.parseInt(arrivalField.getText());
            int burst = Integer.parseInt(burstField.getText());

            // Create a Process object and add it to the list
            Priority.Process process = new Priority.Process(id, priority, arrival, burst);
            processes.add(process);

            // Update output area with the added process
            outputArea.append("Process " + id + " added\n");

            // Clear the input fields after adding the process
            idField.setText("");
            priorityField.setText("");
            arrivalField.setText("");
            burstField.setText("");
        } catch (NumberFormatException e) {
            outputArea.append("Invalid input. Please enter valid numbers.\n");
        }
    }

    // Schedule the processes using the Priority class
    private void scheduleProcesses() {
        if (processes.isEmpty()) {
            outputArea.append("No processes to schedule.\n");
            return;
        }

        // Call the schedule method of the Priority class to execute the scheduling
        Priority.schedule(processes, outputArea);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new PriorityWindow();  // Open the Priority window
            }
        });
    }
}
