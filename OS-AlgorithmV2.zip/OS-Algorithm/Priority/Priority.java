// Priority.java (This now includes both the Process class and scheduling logic)
import java.util.List;
import java.util.PriorityQueue;
import java.util.Comparator;
import javax.swing.JTextArea;

public class Priority {

    // Process class holds information about each process
    public static class Process {
        private String id;
        private int priority;
        private int arrivalTime;
        private int burstTime;
        private int remainingTime;

        // Constructor to initialize process details
        public Process(String id, int priority, int arrivalTime, int burstTime) {
            this.id = id;
            this.priority = priority;
            this.arrivalTime = arrivalTime;
            this.burstTime = burstTime;
            this.remainingTime = burstTime;
        }

        // Getters and setters for process details
        public String getId() {
            return id;
        }

        public int getPriority() {
            return priority;
        }

        public int getArrivalTime() {
            return arrivalTime;
        }

        public int getBurstTime() {
            return burstTime;
        }

        public int getRemainingTime() {
            return remainingTime;
        }

        public void setRemainingTime(int remainingTime) {
            this.remainingTime = remainingTime;
        }

        // Decrement remaining time when a unit of time is executed
        public void decrementRemainingTime() {
            this.remainingTime--;
        }
    }

    // Priority Preemptive Scheduling logic
    public static void schedule(List<Process> processes, JTextArea outputArea) {
        processes.sort(Comparator.comparingInt(Process::getArrivalTime)); // Sort by arrival time

        int time = 0;
        PriorityQueue<Process> readyQueue = new PriorityQueue<>(Comparator.comparingInt(Process::getPriority)); // Min heap based on priority
        int index = 0;
        Process currentProcess = null;

        while (index < processes.size() || !readyQueue.isEmpty() || currentProcess != null) {
            // Add all processes that have arrived by the current time
            while (index < processes.size() && processes.get(index).getArrivalTime() <= time) {
                readyQueue.add(processes.get(index));
                index++;
            }

            // Preempt the current process if a new higher-priority process is available
            if (currentProcess != null && !readyQueue.isEmpty() && currentProcess.getPriority() > readyQueue.peek().getPriority()) {
                readyQueue.add(currentProcess); // Re-add current process to ready queue
                currentProcess = readyQueue.poll(); // Take the highest priority process
            }

            // If there's a process ready, it can now be executed
            if (currentProcess == null && !readyQueue.isEmpty()) {
                currentProcess = readyQueue.poll();
            }

            if (currentProcess != null) {
                outputArea.append("Time " + time + ": Process " + currentProcess.getId() + " is executing.\n");
                currentProcess.decrementRemainingTime();

                if (currentProcess.getRemainingTime() > 0) {
                    // If Process isn't finished, add it back to ready queue
                    readyQueue.add(currentProcess);
                    currentProcess = null; // Remove the current process from execution
                } else {
                    outputArea.append("Time " + (time + 1) + ": Process " + currentProcess.getId() + " finished.\n");
                    currentProcess = null; // Finished, reset
                }
            }

            // Increment time
            time++;
        }
    }
}
