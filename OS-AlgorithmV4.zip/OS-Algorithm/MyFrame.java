import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import SJF.SJFWindow;
import CLook.CLOOKWindow;

public class MyFrame extends JFrame {

    public MyFrame() {
        setTitle("Scheduling and Disk Scheduling Algorithms");
        setSize(500, 400);
        setLocationRelativeTo(null); 
        setResizable(false);

        setUIFont(new Font("Roboto", Font.PLAIN, 14));

        initComponent();
        initEvent();
    }

    private void initComponent() {
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Scheduling & Disk Scheduling Simulator", JLabel.CENTER);
        titleLabel.setFont(new Font("Roboto", Font.BOLD, 20));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        mainPanel.add(titleLabel, gbc);

        JPanel centerPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JButton btnSJF = new JButton("SJF Scheduling");
        JButton btnPriority = new JButton("Priority Preemptive Scheduling");
        JButton btnCLook = new JButton("C-LOOK Disk Scheduling");

        centerPanel.add(btnSJF);
        centerPanel.add(btnPriority);
        centerPanel.add(btnCLook);

        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        mainPanel.add(centerPanel, gbc);

        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        JButton btnExit = new JButton("Exit");
        footerPanel.add(btnExit);

        gbc.gridy = 2;
        mainPanel.add(footerPanel, gbc);

        add(mainPanel);

        // Event Listeners
        btnSJF.addActionListener(e -> {
            this.setVisible(false);
            new SJFWindow(this);
        });

        btnCLook.addActionListener(e -> {
            this.setVisible(false);
            new CLOOKWindow(this);
        });

        // Open Priority Preemptive Scheduling window
        btnPriority.addActionListener(e -> {
            this.setVisible(false);
            new PriorityWindow(this);  // Open the PriorityWindow
        });

        btnExit.addActionListener(e -> System.exit(0)); 
    }

    private void initEvent() {
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }

    private static void setUIFont(Font font) {
        java.util.Enumeration<Object> keys = UIManager.getDefaults().keys();
        while (keys.hasMoreElements()) {
            Object key = keys.nextElement();
            Object value = UIManager.get(key);
            if (value instanceof javax.swing.plaf.FontUIResource) {
                UIManager.put(key, font);
            }
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        MyFrame frame = new MyFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
