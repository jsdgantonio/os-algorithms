import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;

public class PriorityWindow extends JFrame {
    private JTextField idField, priorityField, arrivalField, burstField;
    private JTextArea outputArea;
    private List<Priority.Process> processes;
    private MyFrame parentFrame;  // Reference to the parent frame (MyFrame)

    public PriorityWindow(MyFrame parentFrame) {
        this.parentFrame = parentFrame; // Initialize parent frame reference
        setTitle("Priority Preemptive Scheduling");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        processes = new ArrayList<>();

        // Input fields for the process details
        JPanel inputPanel = new JPanel(new GridLayout(5, 2));
        inputPanel.add(new JLabel("Process ID:"));
        idField = new JTextField();
        inputPanel.add(idField);

        inputPanel.add(new JLabel("Priority:"));
        priorityField = new JTextField();
        inputPanel.add(priorityField);

        inputPanel.add(new JLabel("Arrival Time:"));
        arrivalField = new JTextField();
        inputPanel.add(arrivalField);

        inputPanel.add(new JLabel("Burst Time:"));
        burstField = new JTextField();
        inputPanel.add(burstField);

        // Add Process Button
        JButton addButton = new JButton("Add Process");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addProcess();
            }
        });
        inputPanel.add(addButton);

        // Output area to display scheduling results
        outputArea = new JTextArea();
        outputArea.setEditable(false);

        // Schedule Button (for Priority Preemptive Scheduling)
        JButton scheduleButton = new JButton("Schedule");
        scheduleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                scheduleProcesses();
            }
        });

        // Back Button to return to MyFrame
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            dispose(); // Close the current window
            parentFrame.setVisible(true); // Show the parent frame
        });

        // Clear Button to reset the fields and output
        JButton clearButton = new JButton("Clear");
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });

        // Layout to place buttons correctly
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(scheduleButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(backButton);

        // Add components to the JFrame
        add(inputPanel, BorderLayout.NORTH);
        add(new JScrollPane(outputArea), BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    // Add process details from the input fields to the processes list
    private void addProcess() {
        try {
            String id = idField.getText();
            int priority = Integer.parseInt(priorityField.getText());
            int arrival = Integer.parseInt(arrivalField.getText());
            int burst = Integer.parseInt(burstField.getText());

            // Create a Process object and add it to the list
            Priority.Process process = new Priority.Process(id, priority, arrival, burst);
            processes.add(process);

            // Update output area with the added process
            outputArea.append("Process " + id + " added\n");

            // Clear the input fields after adding the process
            idField.setText("");
            priorityField.setText("");
            arrivalField.setText("");
            burstField.setText("");
        } catch (NumberFormatException e) {
            outputArea.append("Invalid input. Please enter valid numbers.\n");
        }
    }

    // Schedule the processes using the Priority class
    private void scheduleProcesses() {
        if (processes.isEmpty()) {
            outputArea.append("No processes to schedule.\n");
            return;
        }

        // Call the schedule method of the Priority class to execute the scheduling
        Priority.schedule(processes, outputArea);
    }

    // Clear the input fields and the output area
    private void clearFields() {
        // Clear input fields
        idField.setText("");
        priorityField.setText("");
        arrivalField.setText("");
        burstField.setText("");
        
        // Clear the output area
        outputArea.setText("");
        
        // Clear the processes list
        processes.clear();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                MyFrame parentFrame = new MyFrame(); // Create the parent frame instance
                new PriorityWindow(parentFrame);  // Open the Priority window
                parentFrame.setVisible(false); // Hide parent frame initially
            }
        });
    }
}
