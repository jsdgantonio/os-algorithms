package SJF;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.util.Comparator;

public class SJF {
    private static class Process {
        String id;
        int arrivalTime;
        int burstTime;
        int completionTime;
        int turnAroundTime;
        int waitingTime;

        Process(String id, int arrivalTime, int burstTime) {
            this.id = id;
            this.arrivalTime = arrivalTime;
            this.burstTime = burstTime;
        }
    }

    private final ArrayList<Process> processes = new ArrayList<>();

    public void addProcess(String id, int arrivalTime, int burstTime) {
        processes.add(new Process(id, arrivalTime, burstTime));
    }

    public void clearProcesses() {
        processes.clear();
    }

    public void schedule(JFrame frame, JTable table) {
        if (processes.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "No processes to schedule!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Sort processes by arrival time
        processes.sort(Comparator.comparingInt(p -> p.arrivalTime));

        int currentTime = 0;
        double totalTAT = 0, totalWT = 0;

        ArrayList<Process> completedProcesses = new ArrayList<>();

        while (!processes.isEmpty()) {
            // Find the process with the smallest burst time that has arrived
            Process nextProcess = null;
            for (Process process : processes) {
                if (process.arrivalTime <= currentTime) {
                    if (nextProcess == null || process.burstTime < nextProcess.burstTime) {
                        nextProcess = process;
                    }
                }
            }

            // If no process has arrived, skip time to the next process's arrival
            if (nextProcess == null) {
                currentTime = processes.get(0).arrivalTime;
                continue;
            }

            // Remove the selected process from the list
            processes.remove(nextProcess);

            // Update current time and calculate metrics
            currentTime = Math.max(currentTime, nextProcess.arrivalTime) + nextProcess.burstTime;
            nextProcess.completionTime = currentTime;
            nextProcess.turnAroundTime = nextProcess.completionTime - nextProcess.arrivalTime;
            nextProcess.waitingTime = nextProcess.turnAroundTime - nextProcess.burstTime;

            totalTAT += nextProcess.turnAroundTime;
            totalWT += nextProcess.waitingTime;

            completedProcesses.add(nextProcess);
        }

        // Sort the completed processes by process ID for display
        completedProcesses.sort(Comparator.comparing(p -> p.id));

        // Prepare the results table
        DefaultTableModel model = new DefaultTableModel(
            new String[]{"Process ID", "AT", "BT", "CT", "TAT", "WT"}, 0
        );

        for (Process p : completedProcesses) {
            model.addRow(new Object[]{
                p.id, p.arrivalTime, p.burstTime,
                p.completionTime, p.turnAroundTime, p.waitingTime
            });
        }

        // Add average TAT and WT at the end of the table
        model.addRow(new Object[]{
            "Avg.", "", "", "",
            String.format("%.2f", totalTAT / completedProcesses.size()),
            String.format("%.2f", totalWT / completedProcesses.size())
        });

        // Set the table model
        table.setModel(model);
    }
}
