import java.util.List;
import java.util.PriorityQueue;
import java.util.Comparator;

public class PriorityScheduler {
    private List<Process> processes;

    public PriorityScheduler(List<Process> processes) {
        this.processes = processes;
    }

    public void schedule(ScheduleCallback callback) {
        processes.sort(Comparator.comparingInt(Process::getArrivalTime));

        int time = 0;
        PriorityQueue<Process> readyQueue = new PriorityQueue<>(Comparator.comparingInt(Process::getPriority));
        int index = 0;
        Process currentProcess = null;

        while (index < processes.size() || !readyQueue.isEmpty() || currentProcess != null) {
            while (index < processes.size() && processes.get(index).getArrivalTime() <= time) {
                readyQueue.add(processes.get(index));
                index++;
            }

            if (currentProcess != null && !readyQueue.isEmpty()
                    && currentProcess.getPriority() > readyQueue.peek().getPriority()) {
                readyQueue.add(currentProcess);
                currentProcess = readyQueue.poll();
            }

            if (currentProcess == null && !readyQueue.isEmpty()) {
                currentProcess = readyQueue.poll();
            }

            if (currentProcess != null) {
                callback.onEvent(time, currentProcess.getId(), "executing");
                currentProcess.decrementRemainingTime();

                if (currentProcess.getRemainingTime() == 0) {
                    callback.onEvent(time + 1, currentProcess.getId(), "finished");
                    currentProcess = null;
                }
            }

            time++;
        }
    }

    public interface ScheduleCallback {
        void onEvent(int time, String processId, String status);
    }
}
